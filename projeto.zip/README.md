# rp02_imoveis_grupo07

## Grupo 08
Bruna de Abreu Dias,
Clever Oliveira,
Juliana Medeiros,
Leonardo Rivaldo
